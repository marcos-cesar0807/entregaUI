import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { App } from '../../App';
import { DoDont, Page, Section } from './ui';

const meta = {
  title: 'Fundamentos/Grid e layout',
  tags: ['!autodocs'],
  parameters: { layout: 'fullscreen' },
} satisfies Meta;
export default meta;
type Story = StoryObj<typeof meta>;

function Phone() {
  const [guides, setGuides] = useState(true);
  return (
    <div className="fd-stage">
      <div className="fd-phone">
        <App initialScreen="list" />
        {guides && (
          <div className="fd-guides" aria-hidden="true">
            <i style={{ left: 0, width: 16 }} /><i style={{ right: 0, width: 16 }} />
            <span style={{ left: 2 }}>16</span><span style={{ right: 2 }}>16</span>
            <span style={{ left: 16 + 185 - 40, top: 'auto', bottom: 104 }}>conteúdo 370</span>
          </div>
        )}
      </div>
      <div className="fd-legend">
        <label className="fd-toggle"><input type="checkbox" checked={guides} onChange={e => setGuides(e.target.checked)} /> Mostrar margens</label>
        <div className="fd-card">
          <p className="fd-label">Medidas da tela</p>
          <table>
            <tbody>
              <tr><td>Largura da coluna</td><td><b>402px</b></td></tr>
              <tr><td>Margem lateral</td><td><b>16px</b> de cada lado</td></tr>
              <tr><td>Conteúdo útil</td><td><b>370px</b> (402 − 16 − 16)</td></tr>
              <tr><td>Colunas</td><td><b>1</b> (o cartão tem 2 colunas por dentro)</td></tr>
              <tr><td>Calha</td><td><b>12px</b> entre peças do mesmo bloco · <b>16px</b> entre cartões</td></tr>
            </tbody>
          </table>
        </div>
        <p className="fd-muted">Este é o app de verdade, com as margens desenhadas por cima. Tudo que é conteúdo respeita as duas faixas vermelhas; só imagens de fundo (como o topo do detalhe) vão de ponta a ponta.</p>
      </div>
    </div>
  );
}

const layers = [
  { z: 'Folha (bottom sheet)', d: 'Sobe de baixo, escurece o fundo e prende o foco. Cantos de cima a 24px.', c: 'var(--color-bg-secondary)', fg: '' },
  { z: 'Aviso (toast)', d: 'Fica acima das barras de baixo e nunca cobre o botão principal.', c: 'var(--color-bg-inverse)', fg: 'var(--color-text-inverse)' },
  { z: 'Barra de ação e barra de abas', d: 'Flutuam no rodapé, 16px da borda de baixo. A barra de abas encolhe a 80% ao rolar.', c: 'var(--glass-bg)', fg: '' },
  { z: 'Barra do topo', d: '64px de altura. Botões sempre; vidro e título pequeno só depois de rolar.', c: 'var(--glass-bg)', fg: '' },
  { z: 'Conteúdo da tela', d: 'Começa 64px abaixo do topo e deixa reserva no fim para as barras não cobrirem o último item.', c: 'var(--color-bg-primary)', fg: '' },
];

export const Guia: Story = {
  name: 'Guia visual',
  render: () => (
    <Page
      title="Grid e layout"
      lead="Uma coluna de celular, margens iguais e poucas camadas. É o esqueleto sobre o qual todo o resto se apoia."
      rule="Desenhe sempre em 402px de largura, com 16px de margem e uma coluna de conteúdo; a versão larga só centraliza essa mesma coluna."
    >
      <Section n={1} title="A tela de celular" intro="A Marina só tem celular, então a coluna é o produto. Ligue e desligue as margens para ver o que fica dentro delas.">
        <Phone />
      </Section>

      <Section n={2} title="As camadas da tela" intro="De baixo para cima. Quem está em cima nunca esconde a ação principal de quem está embaixo.">
        <div className="fd-card" style={{ display: 'grid', gap: 8 }}>
          {layers.map((l, i) => (
            <div key={l.z} style={{ display: 'grid', gridTemplateColumns: '32px 1fr', gap: 12, alignItems: 'center', marginLeft: (layers.length - 1 - i) * 0 }}>
              <span className="fd-num">{layers.length - i}</span>
              <div style={{ display: 'flex', gap: 16, alignItems: 'center', padding: 12, borderRadius: 24, background: l.c, boxShadow: 'inset 0 0 0 1px var(--color-border-default)' }}>
                <b style={{ flex: 'none', width: 200, color: l.fg || undefined }}>{l.z}</b><span style={{ color: l.fg || 'var(--color-text-secondary)' }}>{l.d}</span>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section n={3} title="Alvos de toque" intro="Todo controle tem 48px de altura. Dois ficam menores de propósito (chips 36px e seletor 40px) e continuam acima do mínimo de 24px da norma (WCAG 2.5.8).">
        <div className="fd-cols">
          <div className="fd-card" style={{ display: 'flex', gap: 24, alignItems: 'flex-end', flexWrap: 'wrap' }}>
            {[[48, 'Botões, busca, abas, +'], [40, 'Seletor'], [36, 'Chips'], [24, 'Mínimo da norma']].map(([s, t]) => (
              <div key={String(t)} style={{ textAlign: 'center' }}>
                <div style={{ width: Number(s), height: Number(s), borderRadius: 8, background: 'var(--color-action-primary-default)', margin: '0 auto 8px', opacity: s === 24 ? 0.4 : 1 }} />
                <b>{s}px</b><div className="fd-small fd-muted" style={{ maxWidth: 96 }}>{t}</div>
              </div>
            ))}
          </div>
          <DoDont doText="Dê 48px de altura a qualquer coisa que se toca com o polegar." dontText="Colocar dois controles pequenos colados: o toque pega o vizinho." />
        </div>
      </Section>

      <Section n={4} title="Quando a tela muda de largura" intro="Duas quebras, e as duas nascem da largura do texto, não do nome de um aparelho.">
        <div className="fd-cols">
          <div className="fd-card">
            <p className="fd-label">Abaixo de 360px</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 3fr', gap: 12, marginTop: 12, alignItems: 'center' }}>
              <div style={{ aspectRatio: '1', borderRadius: 8, background: 'var(--color-purple-100)' }} />
              <div className="fd-muted">a arte encolhe de 1/3 para 1/4 da largura do cartão</div>
            </div>
            <p className="fd-muted" style={{ marginTop: 12 }}>Sem isso, o texto do cartão ficaria com menos de uns 25 caracteres por linha e quebraria demais.</p>
          </div>
          <div className="fd-card">
            <p className="fd-label">A partir de 600px</p>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 12, background: 'var(--color-bg-tertiary)', padding: 12, borderRadius: 8 }}>
              <div style={{ width: 120, height: 96, borderRadius: 24, background: 'var(--color-bg-secondary)', boxShadow: 'var(--shadow-float)' }} />
            </div>
            <p className="fd-muted" style={{ marginTop: 12 }}>A coluna de 402px (cerca de 60 caracteres por linha, o limite de leitura confortável) fica centralizada, com cantos de 24 e sombra.</p>
          </div>
        </div>
      </Section>

      <Section n={5} title="O que não fazer">
        <DoDont doText="Alinhar tudo às margens de 16px; imagem de fundo pode sangrar até a borda." dontText="Criar uma segunda coluna ou uma grade de 12 colunas: o produto é de uma coluna só." />
      </Section>
    </Page>
  ),
};
