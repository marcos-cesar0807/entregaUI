/** Remove o `# Título` inicial do markdown de `docs/componentes`, já que o Storybook Docs mostra o próprio título do componente. */
export function docBody(markdown: string) {
  return markdown.replace(/^#\s.*\n/, '');
}
