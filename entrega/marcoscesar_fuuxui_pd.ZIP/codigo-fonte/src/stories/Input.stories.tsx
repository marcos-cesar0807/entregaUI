import type { Meta, StoryObj } from '@storybook/react-vite';
import { Input } from '../components/atoms/Input';
import { Icon } from '../components/atoms/Icon';
import campoDeBuscaDoc from '../../docs/componentes/campo-de-busca.md?raw';
import { docBody } from './docBody';

const meta = {
  title: 'Átomos/Input',
  component: Input,
  args: { placeholder: 'Digite aqui', 'aria-label': 'Campo de exemplo', startIcon: <Icon name="search" size={20} /> },
  parameters: {
    docs: {
      description: {
        component:
          'Átomo puro (`div` + `input` + ícones opcionais), sem rótulo nem mensagem de erro próprios — ' +
          'quem monta esses dois é a molécula `Moléculas/Campo de busca`, documentada abaixo por reunir ' +
          'as mesmas sete seções (o Input é a peça "Anatomia" dela).\n\n' + docBody(campoDeBuscaDoc),
      },
    },
  },
} satisfies Meta<typeof Input>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Padrao: Story = {};
export const Preenchido: Story = { args: { defaultValue: 'Cálculo I' } };
export const Desabilitado: Story = { args: { disabled: true } };
export const Invalido: Story = { args: { invalid: true, 'aria-label': 'Campo inválido' } };
