# O caso Marina — Design System e matrícula

**Entrega principal: caminho B, código.** Projeto React para o fluxo de matrícula móvel da persona Marina, com Design System documentado em Storybook. O enunciado está rastreado em [`docs/criterios-do-projeto.md`](docs/criterios-do-projeto.md).

## Estado (03/10/2026)

Fluxo completo e navegável: Início → Disciplinas (T1) → Detalhe (T2) → Resumo (T3) → Confirmação (T4) → Minhas matrículas (T5), mais Agenda. Estados: E1 (sem resultado), E2 (carregando), **E3 (vaga esgotada durante a decisão, ao tocar Confirmar na T3)** e E4 (busca com mais de 60 caracteres). As quatro saídas existem: voltar preserva, cancelar descarta, desfazer reverte e fechar não altera nada. O percurso T1→T5 foi verificado só com teclado. **Pendências:** teste com pessoa, decisões da revisão heurística (cabem ao estudante) e o envio no Moodle. Detalhe em [`docs/criterios-do-projeto.md`](docs/criterios-do-projeto.md) e [`docs/handoff.md`](docs/handoff.md).

## Estrutura

```text
.storybook/                 Configuração do Storybook
docs/                      Critérios, decisões, tokens, componentes e handoff
evidencias/foco/            Print da ordem de foco (T1, 27 paradas)
src/components/atoms/      Botão, input, badge, chip, checkbox e ícone
src/components/molecules/  Busca e mensagem de sistema
src/components/organisms/  Cartão de disciplina e resumo fixo
src/flows/                 Telas e estados
src/styles/                Tokens CSS
src/stories/               Histórias do Storybook
```

## Desenvolvimento

Depois de `npm install`:

- `npm run dev`: protótipo durante o desenvolvimento.
- `npm run storybook`: componentes e variantes. O grupo **Fundamentos** tem as páginas visuais do design system para designers (comece por *Comece aqui*).
- `npm run build`: build convencional em `dist/`.
- `npm run build:offline`: `offline/index.html` com JavaScript, CSS e fontes embutidos; manter a pasta `offline/assets/` junto do HTML.
- `npm run build-storybook`: Storybook estático em `storybook-static/`.

As **115 variáveis locais** do Figma foram traduzidas em `src/styles/figma-tokens.css` e `src/styles/figma-tokens.json`, fonte única de verdade dos tokens. A seleção de 38 tokens explicada para a disciplina está em `docs/design-system.md`; a documentação completa e descritiva das 115 variáveis está no Storybook, em **Fundamentos/Tokens**. `src/styles/tailwind-theme.css` espelha esses tokens no namespace `@theme` do Tailwind (v4, via `@tailwindcss/vite`) para uso em classes utilitárias; os componentes existentes continuam em CSS puro. Os assets visíveis da T1 estão no projeto, sem URLs temporárias do Figma.

## Entrega planejada

O ZIP deve incluir LEIA-ME com caminho principal e instruções para abrir, protótipo que abra no navegador sem instalar dependências, documentação em **um PDF único**, registro de IA e prints de T1 com ordem de foco numerada. O build `offline/` prepara esse formato, mas a abertura direta via `file://` ainda deve ser conferida na máquina do estudante. Prazo do PDF: **05/10/2026, 23h59**, via Moodle.
